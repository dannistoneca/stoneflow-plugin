<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

function stoneflow_admin_page_content() {
    ?>
    <div class="wrap">
        <h1>Welcome to StoneFlow</h1>
        <p>This is your admin dashboard. From here, you'll manage clients, services, and project tasks.</p>
        <p>More features coming soon in the next version!</p>
    </div>
    <?php
}
